package com.eight;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

public class CompleteableFutureEg {
	public static void main(String[] args) {
		try {
			List<Integer> list = Arrays.asList(5, 9, 14);
			list.stream()
			.map(num -> CompletableFuture.supplyAsync(() -> getNumber(num)).thenApply(n -> n * n))
			.map(t -> {
				try {
					return t.get();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ExecutionException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				return new Integer(0);
			})
			.forEach(s -> System.out.println(s));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static int getNumber(int a) {
		return a * a;
	}
}
