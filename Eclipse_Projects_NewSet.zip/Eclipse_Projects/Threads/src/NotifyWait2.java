public class NotifyWait2 {
	static Calculator1 b;
	public static void main(String[] args) {
		for(int x=5;x<=10;x++)
		{
			b = new Calculator1();
			b.start();
			
			System.out.println("----------<O>----------");
			synchronized(b)
			{
				try{
					b.iv = x;
					System.out.println("A:waiting for b thread to complete...");
					b.wait();
					//Thread.sleep(0,10);
					System.out.println("after wait()....");
				}catch(Exception e) {
					System.out.println("Interrupted Exception:"+e.getMessage());
					e.printStackTrace();
				}
				
				System.out.println("Total is:"+b.total);
			}
			System.out.println("----------------------");
		}//enf of for
	}
}


class Calculator1 extends Thread{
	int total;
	int iv;
	
	public void run(){
		
		try
		{
		System.out.println("in run() method of Child thread");
		synchronized(NotifyWait2.b)
		{
			for(int i=0;i<iv;i++)
			{
				
				total += i;
				Thread.sleep(1000);
				
			}
			
			NotifyWait2.b.notify();
			System.out.println("notify() invoked from Child thread");
		}
		}catch(Exception et)
		{
			System.out.println(et);
		}
		
		System.out.println("Exiting Calculator");
		
	}
}
