/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaio;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class BufferedReaderDemo {

	public static void main(String[] args) {           
		try 
//(BufferedReader br = new BufferedReader(new FileReader("abc.txt")))
		{
                   FileReader fr = new FileReader("abc.txt");
            BufferedReader br = new BufferedReader(fr);

		String sCurrentLine;

		while ((sCurrentLine = br.readLine()) != null) {
			System.out.println(sCurrentLine);
		}

		} catch (IOException e) {
			e.printStackTrace();
		} 

	}
}