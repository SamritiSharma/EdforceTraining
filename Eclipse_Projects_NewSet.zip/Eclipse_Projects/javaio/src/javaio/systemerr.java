/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaio;

/**
 *
 * @author ADMIN
 */
public class systemerr {
    public static void main(String args[])
    {
        System.err.println("This is standard error stream");
        System.err.printf("print Testing");
        int i = 10;
        String str = "fdsfsdfsd";
        System.out.printf("%d %s\n",i,str);
    }
}
