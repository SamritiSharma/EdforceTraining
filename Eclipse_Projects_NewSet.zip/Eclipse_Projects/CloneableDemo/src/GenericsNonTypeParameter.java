
class Base<T1>
{
	private T1 ot;
	
	public Base(T1 ot)
	{
		this.ot = ot;
	}
	
	public T1 getT1()
	{
		return ot; 
	}
	
	public void print()
	{
		System.out.println("Base class "+ot);
	}
}

class Derived<T2> extends Base<Integer>
{
	
}

public class GenericsNonTypeParameter {
	public static void main(String[] args) {
		
	}
}
