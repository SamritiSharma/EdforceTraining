
public class Qrs
{
	void display(){perform();}
static void perform(){display();}
public static void main(String args[]){perform();}}
