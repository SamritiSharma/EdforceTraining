class Mno{
	static{
		System.out.println("This is static block");
	}
}

public class StaticBlockEg {
	public static void main(String[] args) {
		Mno obj1 = new Mno();
		Mno obj2 = new Mno();
	}
}
