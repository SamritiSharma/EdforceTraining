import java.util.concurrent.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;


public class CallableEgSimple2
{
      public static void main(String[] args) throws Exception
      {
    	  Thread t = new Thread(new FCalculator(new Integer(23)));
      }
}
