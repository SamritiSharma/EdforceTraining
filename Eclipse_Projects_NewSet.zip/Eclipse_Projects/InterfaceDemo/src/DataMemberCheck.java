
interface Eg{
	int a=10;
}
public class DataMemberCheck {
	public static void main(String[] args) {
		Eg.a = 20;
		//Note: interface data members are static and final by default
	}
}
