
public class SecondProgram {
public static void main(String args[])
{
	int x = 20, y = 23;
	
	System.out.println("before if");
	if((x<15) || (y>40))
	{
		System.out.println("x is less than 15");
	}
	else
	{
		System.out.println("x is greater than or equal to 15");
	}
	System.out.println("after if");
}
}
