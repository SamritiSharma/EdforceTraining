
public class ConditionalOperator {
	public static void main(String args[])
	{
		int x = 3,y;
		
		y = (x<5)?20:10;
		
		System.out.println("y is "+y);
	}
}
