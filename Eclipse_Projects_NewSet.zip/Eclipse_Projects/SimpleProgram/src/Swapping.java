
public class Swapping {
	public static void main(String[] args) {
		int x, y, z;
		 x = 12;
		 y = 23;
		 
		 System.out.println("Before swapping x="+x+"  y="+y);
		 
		 z = x;
		 x = y;
		 y = z;
		 
		 System.out.println("After swapping x="+x+"  y="+y);
	}
}
