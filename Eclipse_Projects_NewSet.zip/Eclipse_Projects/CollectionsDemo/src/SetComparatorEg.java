import java.util.Comparator;
import java.util.TreeSet;

public class SetComparatorEg {
public static void main(String[] args) {
	//Comparator<Developer> byName = 
	//		(Developer o1, Developer o2)->o1.getName().compareTo(o2.getName());
			
	TreeSet<String> tss = 
		new TreeSet<String>((str1, str2)->str1.length()-str2.length());

	tss.add("aaaaa");
	tss.add("a");
	tss.add("aaa");
	tss.add("aaaaaaaa");
	tss.add("aa");
	
	System.out.println(tss);
}
}

class MyComp9 implements Comparator<String>{
	public int compare(String str1, String str2)
	{
		return str1.length()-str2.length();
	}
}
