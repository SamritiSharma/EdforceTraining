import java.util.*;

public class ArrayListEg {
	public static void main(String[] args) {
		
		ArrayList<String> alt = new ArrayList<String>();
		alt.add("1111111111");
		alt.add("222222");
		
		LinkedList<String> al = new LinkedList<String>();
		
		al.addAll(alt);
		al.add("aaaaa");
		al.addFirst("gggggggggg");
		al.add("jhastdgdh");
		al.add("bbbbb11");
		al.add("ccccc");
		al.add("zzzzz");
		al.add("bbbbb22");
		
		al.remove(al.size()-1);
		
		//ListIterator itr = al.listIterator(al.size());
		
		Iterator<String> itr = al.iterator();
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		
		System.out.println("Size is "+al.size());
		
	}
}
