
public class AutoBoxingUnboxing {
	public static void main(String args[])
	{
		//auto boxing, automatically converts int to Integer
		Integer iObj = 10;
		
		Integer iObj1 = new Integer(20);
		
		//auto unboxing, automatically converts 
		int i = iObj1;
		Integer.
		display(1.1f, 2.2f);
	}
	
	static void display(Float val1, Float val2)
	{
		System.out.println("Display(): "+val1+" "+val2);
	}
}
