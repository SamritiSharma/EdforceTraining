
import java.util.ArrayList; 
import java.util.List; 
import java.util.Map;
import java.util.stream.Collectors;
import java.util.HashMap;
import java.util.LinkedHashMap; 
  
// create a list 
class Student88 { 
  
    // id will act as Key 
    private Integer id; 
  
    // name will act as value 
    private String name; 
  
    // create constructor for reference 
    public Student88(Integer id, String name) 
    { 
  
        // assign the value of id and name 
        this.id = id; 
        this.name = name; 
    } 
  
    // return private variable id 
    public Integer getId() 
    { 
        return id; 
    } 
  
    // return private variable name 
    public String getName() 
    { 
        return name; 
    } 
} 
  
// main class and method 
public class ListToMapStreams { 
  
    // main Driver 
    public static void main(String[] args) 
    { 
  
        // create a list 
        List<Student88> 
            lt = new ArrayList<Student88>(); 
  
        // add the member of list 
        lt.add(new Student88(1, "Geeks")); 
        lt.add(new Student88(2, "For")); 
        lt.add(new Student88(3, "Geeks")); 
  
     // create map with the help of 
        // Collectors.toMap() method 
        LinkedHashMap<Integer, String> 
            map = lt.stream() 
                      .collect( 
                          Collectors 
                              .toMap( 
                                  Student88::getId, 
                                  Student88::getName, 
                                  (x, y) 
                                      -> x + ", " + y, 
                                  LinkedHashMap::new)); 
  
        // print map 
        map.forEach( 
            (x, y) -> System.out.println(x + "=" + y));
    } 
} 

