
public class SimpleException {

	public static void main(String[] args){
			System.out.println("in try");
			
			int i=43,j=2,k;
			
			k = i/j;
			System.out.println("in try 2");
			
			try{
				if(j<=3)
				{
					throw new Exception("Sample message");
				}
			}
			catch(ArithmeticException en)
			{
				System.out.println("Nested try catch:"+en.getMessage());
			}
			catch(Exception ep)
			{
				System.out.println("inner exception:"+ep.getMessage());
			}
			System.out.println("end of outside try");
	}

}
