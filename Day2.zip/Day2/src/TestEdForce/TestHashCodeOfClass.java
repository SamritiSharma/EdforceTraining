package TestEdForce;

	 class Check{
		public void met() {
			System.out.println("the hashvode is "+hashCode());
		}
	
}
	 public  class TestHashCodeOfClass{
		 private static Object myMet(){
			 return new Check() {
				 public void met() {
						System.out.println("the hashcode in innerclass is "+hashCode());
					}
			 };
		 }
	 
	public static void main(String[] args) {
		Object ret=TestHashCodeOfClass.myMet();
		System.out.println("Inside Main");
		((Check)ret).met();
	}
	
}
