package TestEdForce;

public class InnerClassTest {

	public static void main(String[] args) {
	OuterClass oc1=new  OuterClass();
	OuterClass.InnerClass incc=oc1.new InnerClass();
	incc.invoke();
/*class Enr{
	
//class inside method
	}*/
	}

}
class OuterClass{
	
	public class InnerClass{
		public void invoke()
		{
			System.out.println("Called inner class");
		}
	}
}
