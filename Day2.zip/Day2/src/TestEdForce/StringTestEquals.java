package TestEdForce;

public class StringTestEquals {

	public static void main(String[] args) {
String str="abcg";		
String str2="abcg";
str2="pqr";
System.out.println(""+str2);
String str1="abcg";
boolean res=(str1==str);
System.out.println("Resultbool==" +res);
System.out.println("Result==" +(str==str1));
System.out.println("equals"+str.equals(str1));

	}

}
