package TestEdForce;

import java.util.StringJoiner;
import java.util.StringTokenizer;

public class TokenizerTes {
	public static void main(String[] args) {
		String str="abcg;dgqjhdgq;ee3mn;23916;13468jdajhdgjah;3216387";		
		StringTokenizer test=new StringTokenizer(str, ";");
	
		while(test.hasMoreTokens())
		{
			System.out.println("the string tokenized is"+test.nextToken());
		}
		StringJoiner str2= new StringJoiner(",");
	 str2.add("Samriti");
	 str2.add("Sharma");
		System.out.println("Joined String is" +str2);
}
}
