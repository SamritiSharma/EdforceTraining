package com.ab;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnect {
	   static Connection con;
	    public static Connection getConnection()
	    {
	        try
	        {
	            // register jdbc Driver
	            String mysqlJDBCDriver = "com.mysql.cj.jdbc.Driver";
	            Class.forName(mysqlJDBCDriver);
	            String url = "jdbc:mysql://localhost:3306/iris_bank";
	            String user = "root";
	            String pass = "root";
	            con = (Connection) DriverManager.getConnection(url, user, pass);
	        }
	        catch(Exception e)
	        {
	            System.out.println("Connection Failed!");
	        }
	        return con;
	    }
}
