package com.ab;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Statement;

public class BankSevice {


    private static final int NULL = 0;
//DB calls are not working for me so did it both ways one with Db and 
    //other by takign one arraylist of user details and saving in a file instead of DB
    static DBConnect con ;
    static String sql = "";
	public BankSevice() {
		super();
	}

	ArrayList<Account> AL = new ArrayList<Account>(); 
	
	public void addNewRecord()
	{
		Scanner input = new Scanner(System.in);

		System.out.print("\nEnter name of Account Holder: ");
		String n = input.nextLine();
		System.out.print("Enter an 8 digit Account Number (contact manager for its allocation): ");
		int a = input.nextInt();
		System.out.print("Enter PIN for Account Holder: ");
		String p = input.next();
		System.out.print("Default amount of 1000 is already added to the account, to add more money, write that amount else enter zero: ");
		double am = input.nextDouble();
		
		Account ac = new Account(n, a, p, am);
		AL.add(ac);
		return;
	}
	
	public void transfer()
	{
		Scanner input = new Scanner(System.in);
		System.out.print("\nEnter sender's 8 digit account number: ");
		int s_acc = input.nextInt();
		System.out.print("Enter Sender's pin code: ");
		String s_pin = input.next();

		int sender_index = -1;
		for(int i = 0; i< AL.size(); i++)
		{
			if (AL.get(i).getAccountNumber() == s_acc && AL.get(i).getPIN().equals(s_pin))
				sender_index = i;
		}

		if(sender_index == -1)
		{
			System.out.println("\n Account not Found");
			return;
		}	

		System.out.print("\nEnter receiver's 8 digit account number: ");
		int r_acc = input.nextInt();

		int receiver_index = -1;
		for(int i = 0; i< AL.size(); i++)
		{
			if (AL.get(i).getAccountNumber() == r_acc)
				receiver_index = i;
		}
		
		if(receiver_index == -1)
		{
			System.out.println("\n Receiver's account not Found");
			return;
		}

		System.out.print("\nAmount to be transferred: ");
		double amount = input.nextDouble();
		if(AL.get(sender_index).getAmount() >= amount)
		{
			AL.get(receiver_index).setAmount(AL.get(receiver_index).getAmount() + amount );
			AL.get(sender_index).setAmount(AL.get(sender_index).getAmount() - amount );
			return;
		}
		else 
		{
			System.out.println("\nSender doesnot have this much balance in his account");
			return;
		}	
	}	

	public void withdraw()
	{
		Scanner input = new Scanner(System.in);
		System.out.print("\nEnter User's 8 digit account number: ");
		int p_acc = input.nextInt();
		System.out.print("Enter User's pin code: ");
		String p_pin = input.next();

		int person_index = -1;
		for(int i = 0; i< AL.size(); i++)
		{

			if ((AL.get(i).getAccountNumber() == p_acc) && (AL.get(i).getPIN().equals(p_pin)))
			{
				person_index = i;
			}
		}

		if(person_index == -1)
		{
			System.out.println("\n Account not Found");
			return;
		}	

		System.out.print("\nAmount to be Withdrawn: ");
		double amount = input.nextDouble();
		if(AL.get(person_index).getAmount() >= amount)
		{
			AL.get(person_index).setAmount(AL.get(person_index).getAmount() - amount );
			return;
		}
		else 
		{
			System.out.println("\nThis person doesnot have this much balance in his account");
			return;
		}	
	}

	public void print()
	{
		for(int i = 0; i<AL.size(); i++)
		{
			System.out.println("\nName: " + AL.get(i).getName());
			System.out.println("Account Number: " + AL.get(i).getAccountNumber());
			System.out.println("Balance: " + AL.get(i).getAmount() + "\n");
		}
	}

	public void load()
	{
	 try{
		FileInputStream fis = new FileInputStream("BankRecord.txt");
		ObjectInputStream in = new ObjectInputStream(fis);
		while(true)
		{
			Account temp = (Account) in.readObject(); 
			if(temp == null)
				break;
			AL.add(temp);
		}
		fis.close();
	     }
	 catch(Exception e)
	 {
	 }
	}
	
	public void save()
	{
	 try{
		FileOutputStream fos = new FileOutputStream("BankRecord.txt");
		ObjectOutputStream out = new ObjectOutputStream(fos);
		for(int i = 0; i<AL.size(); i++)
			out.writeObject(AL.get(i));
		fos.close();
	    }
	 catch(Exception e)
	 {
		System.out.println("\nError Saving Data to File");
	 }	
	}
	
	  public static boolean
      createAccount(String name,
                    int passCode,String Emailid,int MobileNo,String dob,String panNo,int ANo, String PO) // create account function
      {
          try {
              // validation
              if (name == "" || passCode == NULL || Emailid == "" || MobileNo == NULL || dob =="" || panNo == "" || ANo == NULL || PO =="") {
                  System.out.println("All Field Required!");
                  return false;
              }
              // query
              Statement st = ((Connection) con).createStatement();
              sql = "INSERT INTO customer(cname,balance,pass_code,Emailid,MobileNo,dob,panNo,ANo,PO) values('"
                      + name + "',1000," + passCode + ",'"+Emailid +"',"+MobileNo+",'"+dob+"',+'"+panNo+"',"+ANo+",'"+PO+"')";

              // Execution
              if (st.executeUpdate(sql) == 1) {
                  System.out.println(name
                          + ", Now You Login!");
                  return true;
              }
              // return
          } catch (SQLIntegrityConstraintViolationException e) {
              System.out.println("Username Not Available!");
          } catch (Exception e) {
              e.printStackTrace();
          }
          return false;
      }

      public static boolean
      loginAccount(String name, int passCode) // login method
      {
          try {
              // validation
              if (name == "" || passCode == NULL) {
                  System.out.println("All Field Required!");
                  return false;
              }
              // query
              sql = "select * from customer where cname='"
                      + name + "' and pass_code=" + passCode;
              PreparedStatement st
                      = ((Connection) con).prepareStatement(sql);
              ResultSet rs = st.executeQuery();
              // Execution
              BufferedReader sc = new BufferedReader(
                      new InputStreamReader(System.in));

              if (rs.next()) {


                  int ch = 5;
                  int amt = 0;
                  int senderAc = rs.getInt("ac_no");

                  int receiveAc;
                  while (true) {
                      try {
                          System.out.println(
                                  "Hallo, "
                                          + rs.getString("cname"));
                          System.out.println(
                                  "1)Transfer Money");
                          System.out.println("2)View Balance");
                          System.out.println("3)Update details");
                          System.out.println("4)LogOut");

                          System.out.print("Enter Choice:");
                          ch = Integer.parseInt(
                                  sc.readLine());
                          if (ch == 1) {
                              System.out.print(
                                      "Enter Receiver A/c No:");
                              receiveAc = Integer.parseInt(
                                      sc.readLine());
                              System.out.print(
                                      "Enter Amount:");
                              amt = Integer.parseInt(
                                      sc.readLine());

                              if (BankSevice.transferMoney(
                                              senderAc, receiveAc,
                                              amt)) {
                                  System.out.println(
                                          "MSG : Money Sent Successfully!\n");
                              } else {
                                  System.out.println(
                                          "ERR : Failed!\n");
                              }
                          } else if (ch == 2) {

                        	  BankSevice.getBalance(
                                      senderAc);
                          }
                          else if (ch == 3) {
                              System.out.println("Enter Updated address");
                              String NewPO = sc.readLine();
                              BankSevice.updateDetails(name,NewPO);
                          }
                          else if (ch == 4) {
                              break;
                          } else {
                              System.out.println(
                                      "Err : Enter Valid input!\n");
                          }
                      } catch (Exception e) {
                          e.printStackTrace();
                      }
                  }
              } else {
                  return false;
              }
              // return
              return true;
          } catch (SQLIntegrityConstraintViolationException e) {
              System.out.println("Username Not Available!");
          } catch (Exception e) {
              e.printStackTrace();
          }
          return false;
      }

  public static boolean updateDetails(String name,String NewPO) throws SQLException {
          try
          {

      sql = "update customer set PO='+ NewPO + ' where cname= '+ name'";

      PreparedStatement p=((Connection) con).prepareStatement(sql);
              p.executeUpdate(sql);


      System.out.println("Updated Successfully!");

              return true;



  } catch (Exception e) {
      e.printStackTrace();

  }

      return false;
  }

  public static void
      getBalance(int acNo)
      {
          try {

              // query
              sql = "select * from customer where ac_no="
                      + acNo;
              PreparedStatement st
                      = ((Connection) con).prepareStatement(sql);

              ResultSet rs = st.executeQuery(sql);
              System.out.println(
                      "-----------------------------------------------------------");
              System.out.printf("%12s %10s %10s\n",
                      "Account No", "Name",
                      "Balance");

              // Execution

              while (rs.next()) {
                  System.out.printf("%12d %10s %10d.00\n",
                          rs.getInt("ac_no"),
                          rs.getString("cname"),
                          rs.getInt("balance"));
              }
              System.out.println(
                      "-----------------------------------------------------------\n");
          } catch (Exception e) {
              e.printStackTrace();
          }
      }

      public static boolean transferMoney(int sender_ac,
                                          int reveiver_ac,
                                          int amount)
              throws SQLException // transfer money method
      {
          // validation
          if (reveiver_ac == NULL || amount == NULL) {
              System.out.println("All Field Required!");
              return false;
          }
          try {
              ((Connection) con).setAutoCommit(false);
              sql = "select * from customer where ac_no="
                      + sender_ac;
              PreparedStatement ps
                      = ((Connection) con).prepareStatement(sql);
              ResultSet rs = ps.executeQuery();

              if (rs.next()) {
                  if (rs.getInt("balance") < amount) {
                      System.out.println(
                              "Insufficient Balance!");
                      return false;
                  }
              }

              Statement st = ((Connection) con).createStatement();

              // debit
              ((Connection) con).setSavepoint();

              sql = "update customer set balance=balance-"
                      + amount + " where ac_no=" + sender_ac;
              if (st.executeUpdate(sql) == 1) {
                  System.out.println("Amount Debited!");
              }

              // credit
              sql = "update customer set balance=balance+"
                      + amount + " where ac_no=" + reveiver_ac;
              st.executeUpdate(sql);

              ((Connection) con).commit();
              return true;
          } catch (Exception e) {
              e.printStackTrace();
              ((Connection) con).rollback();
          }
          // return
          return false;
      }



}
