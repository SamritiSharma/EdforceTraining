package TestEdForce;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.stream.Collectors;

public class HashMapFilterDemo {
	public static void main(String[] args) {
	
	HashMap<String,String> cityState=new HashMap<>();
	cityState.put("Kurukshetra","Haryana");
	cityState.put("Karnal","Haryana");
	cityState.put("Kaitahl","Haryana");
	cityState.put("Dhand","Haryana");
	cityState.put("Lucknow","UP");
	cityState.put("Noida","UP");
 
	Map<String,String> fils=cityState.entrySet().
			stream().filter(e->e.getKey().equals("Kaitahl")).
			collect(Collectors.toMap(e->e.getKey(), e->e.getValue()));
	
	for(Map.Entry<String,String> d:fils.entrySet()) {
		System.out.println("d.getkey"+d.getKey());
		System.out.println("d.getval"+d.getValue());
	}
}}