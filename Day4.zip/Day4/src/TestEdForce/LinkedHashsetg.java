package TestEdForce;

// Java code for Stream filter 
// (Predicate predicate) to get a stream 
// consisting of the elements of this 
// stream that match the given predicate. 
import java.util.*;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream; 

public class LinkedHashsetg { 

	// Driver code 
	public static void main(String[] args) 
	{ 
		LinkedHashSet<String> lhs=new LinkedHashSet<>();
		
		lhs.add("abc");
		
		lhs.add("pqr");
lhs.add("abc");
		
		lhs.add("pqr1");lhs.add("abc2");
		
		lhs.add("pqr2");
		lhs.stream().forEach(System.out::println);
} 
} 
