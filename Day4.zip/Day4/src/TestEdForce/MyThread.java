package TestEdForce;

class PrintChar extends Thread{
public void run(){
for(int i=0;i<MyThread.str.length();i++){
System.out.println("Child Thread..."+MyThread.str.charAt(MyThread.cindex++));
try {
	Thread.sleep(50);
} catch (InterruptedException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
}}
}
public class MyThread {
static String str = "Hello, am explroign mutlithreadin g...";
static int cindex = 0;
public static void main(String[] args) throws InterruptedException {
	
PrintChar pc = new PrintChar();
pc.start();
for(;cindex<str.length();){
System.out.println("Main Thread..."+str.charAt(cindex++));
Thread.sleep(50);}}}
