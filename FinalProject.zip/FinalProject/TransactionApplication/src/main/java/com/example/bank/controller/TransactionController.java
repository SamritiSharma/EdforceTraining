package com.example.bank.controller;

import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.bank.model.BankAccount;
import com.example.bank.service.BankService;


@RestController 
@RequestMapping(name="/bank")
public class TransactionController {

	@Autowired
	BankService bService;
	
	@GetMapping("/")
	String met(){
		return "Hello World!!!";
	}


	//update Bank Account
	@PutMapping("/id/update")
	ResponseEntity<Object> update(@RequestParam("bid") int bid,@RequestParam("amount") Integer amount,@RequestParam("requestType") String requestType){
		//retrieve bank account from db
 bService.updateAccount(bid,amount,requestType);
		  return new ResponseEntity<>("Updated", HttpStatus.OK);
	}
	
}
