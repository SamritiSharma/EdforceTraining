package com.example.bank.repo;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.bank.model.*;


@Repository
@Primary
public interface BankRepository  extends JpaRepository<BankAccount,Long>{
	@Transactional
	@Modifying
@Query(value="delete from BankAccount e where e.id = :id")
	void deleteAccount(@Param("id") int id);
	
	@Transactional
	@Modifying
@Query(value="update BankAccount e set e.name= :name where e.id = :id")
	void updateAccount(@Param("id") int id,@Param("name") String name);
/*	List<BankAccount> baccounts;
	public BankRepository(){
		baccounts = new ArrayList<>();
	}
	
	public BankAccount saveBankAccount(BankAccount bAccount){
		baccounts.add(bAccount);
		return bAccount;
	}
	
	public Optional<BankAccount> getBankAccount(int bid){
		Optional<BankAccount> bAccount = baccounts.stream()
				.filter((e)->bid == e.getBid()).findFirst();
		
		return bAccount;
	}

	public Object deleteAccount(int bid) {
	for(BankAccount l:baccounts)
	{
		if(l.getBid()==bid)
		{
			baccounts.remove(l);
		}
	}
	return bid;
	}

	public Optional<BankAccount> updateAccount(int bid,String name) {
		Optional<BankAccount> bAccount = baccounts.stream()
				.filter((e)->bid == e.getBid()).findFirst();
		for(BankAccount l:baccounts)
		{
			if(l.getBid()==bid)
			{
l.setName(name);
			}
		}
		return bAccount;
	}*/
}
