package com.ab;

public class BankingService {

	public void getBalance(String accNo)
	{
		
	}
}
