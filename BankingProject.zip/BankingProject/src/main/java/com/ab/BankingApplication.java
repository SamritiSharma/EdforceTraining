package com.ab;

import java.util.HashMap;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;

public class BankingApplication {
	// Connection string for JDBC driver
	String connectionUrl = "jdbc:mysql://localhost:3316/bankdb";

	// Username and password for the database
	String dbUsername = "root";
	String dbPassword = "abcdef";
	BankingService service=new BankingService();

	// Establish the connection

	public static void main(String[] args)
	{
		Scanner scanner = new Scanner(System.in);
		HashMap<String, String> users = new HashMap<String, String>();
		users.put("user1", "password1");
		users.put("user2", "password2");

		System.out.println("Enter username:");
		String username = scanner.nextLine();

		System.out.println("Enter password:");
		String password = scanner.nextLine();

		if (users.containsKey(username) && users.get(username).equals(password)) {
			System.out.println("\n1 - Create new Account");
			System.out.println("2 - Transfer money from an existing account to another existing account");
			System.out.println("3 - Withdraw money from existing account");
			System.out.println("4 - Print all exisitng accounts");
			System.out.println("5 - Exit");
			System.out.print("Enter your choice: ");
			Integer choice = scanner.nextInt();
			BankSevice service=new BankSevice();
			if(choice == 1)
			{
				service.addNewRecord();
				System.out.println("\nAccount Created Successfully");
			}
			else if(choice == 2)
			{
				service.transfer();
			}
			else if(choice == 3)
			{
				service.withdraw();
			}
			else if(choice == 4)
				service.print();
			else if(choice == 5)
			{
				service.save();
				System.out.println("\nData saved to File \"BankRecord .txt\"");
				System.exit(1);
			}
			else
				System.out.println("\nWrong Input");
		}
		else {
		    }
		    System.out.println("Incorrect username or password.");
		}
	}

	

