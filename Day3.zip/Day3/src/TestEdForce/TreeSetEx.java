package TestEdForce;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeSet;

class City2{
	String name;
	Integer population;
	public City2(String name, Integer population) {
		super();
		this.name = name;
		this.population = population;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getPopulation() {
		return population;
	}
	public void setPopulation(Integer population) {
		this.population = population;
	}
}
public class TreeSetEx {
	 public static void main(String[] args) {
		TreeSet<City> data=new TreeSet<>((city1,city2)->city2.getPopulation()-city1.getPopulation());
		data.add(new City("KKR", 100));
		data.add(new City("Haryana", 200));

		data.add(new City("Delhi", 300));

		data.add(new City("South", 400));
		for(City data1:data)
		{
			System.out.println("City name" +data1.getName()+" population"+data1.getPopulation());
		}

}}