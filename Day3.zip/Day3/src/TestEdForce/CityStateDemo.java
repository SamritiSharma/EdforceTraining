package TestEdForce;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

public class CityStateDemo {
	public static void main(String[] args) {
	
	HashMap<String,String> cityState=new HashMap<>();
	cityState.put("Kurukshetra","Haryana");
	cityState.put("Karnal","Haryana");
	cityState.put("Kaitahl","Haryana");
	cityState.put("Dhand","Haryana");
	cityState.put("Lucknow","UP");
	cityState.put("Noida","UP");
	
 for(Map.Entry<String, String> data: cityState.entrySet())
 {
	 //System.out.println("City Is "+data.getKey()+"State is "+data.getValue());
	 //get Citied form Kuruskhetsra
	 if(data.getValue().equals("Haryana")) {
		 System.out.println("City Is "+data.getKey());
	 }
 }
}}