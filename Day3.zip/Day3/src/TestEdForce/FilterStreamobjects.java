package TestEdForce;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;


public class FilterStreamobjects{
  public static void main(String[] argv){
    List<Person> persons = Arrays.asList(new Person("Samriti", 12), new Person("Abhinav", 34), new Person("John", 23));

    Stream<Person> personsOver18 = persons.stream().filter(p -> p.getAge() > 18);
   Optional<String> data= Optional.ofNullable(persons.stream().map(n->n.getFirstName()).
		   reduce((a,b)-> a.length()>b.length()?a:b).get());
   System.out.println("data"+data.get());
    //personsOver18.forEach(p -> System.out.println(p.getFirstName()));
  // data.forEach(System.out::println);
   
   List<Person> personName=persons.stream().sorted(Comparator.comparing(Person::getFirstName).reversed()).collect(Collectors.toList());
   personName.forEach(System.out::println);
  }
}

class Person {
    private String firstName;
    private String lastName;
    private int age;

    public Person(String firstName) {
        this.firstName = firstName;
    }

    public Person(String firstName, int age) {
        this.firstName = firstName;
        this.age = age;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    @Override
    public String toString() {
      return "Person [firstName=" + firstName + ", lastName=" + lastName
          + ", age=" + age + "]";
    }
    
}
