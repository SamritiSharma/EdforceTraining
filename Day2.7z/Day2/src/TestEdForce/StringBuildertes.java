package TestEdForce;

public class StringBuildertes {
	public static void main(String[] args) {
		String str="abcg";		
		StringBuilder strBuil=new StringBuilder(str);
		strBuil.append("Samriti");
		strBuil.append(" ");
		strBuil.append("Sharma");
		System.out.println("The final string is "+strBuil);
strBuil.replace(0, 4, "");
System.out.println("The final string after replcae is "+strBuil);
strBuil.deleteCharAt(5);
System.out.println("The final string after delet is "+strBuil);

}
}