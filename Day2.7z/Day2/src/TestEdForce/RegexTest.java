package TestEdForce;

public class RegexTest {

	public static void main(String[] args) {

	}

}
