package Pragram2;
class SavingsBankAccount extends BankAccount {
    private String panNumber;

	public String getPanNumber() {
		return panNumber;
	}

	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}

	
	public SavingsBankAccount(String accountHolderName, String contactNumber, String postalAddress, double currentBalance, String panNumber) {
        super(accountHolderName, contactNumber, postalAddress, currentBalance);
        this.panNumber = panNumber;
    }
    // Constructor and other methods
    
}
