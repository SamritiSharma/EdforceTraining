package Pragram2;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;



public class BankAccount {
    private String accountHolderName;
    private String contactNumber;
    private String postalAddress;
    private double currentBalance;

   	public BankAccount(String accountHolderName, String contactNumber, String postalAddress, double currentBalance) {
		super();
		this.accountHolderName = accountHolderName;
		this.contactNumber = contactNumber;
		this.postalAddress = postalAddress;
		this.currentBalance = currentBalance;
	}

	public void displayAccountDetails() {
        System.out.println("Account Holder Name: " + accountHolderName);
        System.out.println("Contact Number: " + contactNumber);
        System.out.println("Postal Address: " + postalAddress);
        System.out.println("Current Balance: " + currentBalance);
    }

    public String getAccountHolderName() {
		return accountHolderName;
	}

	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getPostalAddress() {
		return postalAddress;
	}

	public void setPostalAddress(String postalAddress) {
		this.postalAddress = postalAddress;
	}

	public double getCurrentBalance() {
		return currentBalance;
	}

	public void setCurrentBalance(double currentBalance) {
		this.currentBalance = currentBalance;
	}

	

        public static void main(String[] args) {
          
            		 BankAccount[] accounts = new BankAccount[3];
            	        accounts[0] = new SavingsBankAccount("John Doe", "1234567890", "Address 1", 5000.0, "ABCDE1234F");
            	        accounts[1] = new CurrentBankAccount("Alice Smith", "9876543210", "Address 2", 10000.0, "GST123456");
            	        accounts[2] = new SavingsBankAccount("Bob Johnson", "5555555555", "Address 3", 3000.0, "FGHIJ5678K");

            	    //String BankAccount;
				List<BankAccount> res= Arrays.stream(accounts).sorted(Comparator.comparing(BankAccount::getAccountHolderName).reversed()).collect(Collectors.toList());//.collect(Collectors.toList());
            	  

            	      //  Arrays.sort(accounts, Comparator.comparing(BankAccount::getAccountHolderName));


            	        for (BankAccount account : res) {
            	            account.displayAccountDetails();
            	        }
        }
    }


