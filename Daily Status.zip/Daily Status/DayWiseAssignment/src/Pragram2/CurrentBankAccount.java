package Pragram2;
class CurrentBankAccount extends BankAccount {
    private String gstNumber;

	public String getGstNumber() {
		return gstNumber;
	}

	public void setGstNumber(String gstNumber) {
		this.gstNumber = gstNumber;
	}

	public CurrentBankAccount(String accountHolderName, String contactNumber, String postalAddress, double currentBalance, String gstNumber) {
        super(accountHolderName, contactNumber, postalAddress, currentBalance);
        this.gstNumber = gstNumber;
    }
    // Constructor and other methods
    
}