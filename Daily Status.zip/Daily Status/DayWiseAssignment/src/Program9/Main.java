package Program9;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

class Producer implements Runnable {
    private BlockingQueue<String> queue;

    public Producer(BlockingQueue<String> queue) {
        this.queue = queue;
    }

    @Override
    public void run() {
        // Produce strings and add them to the queue
        for (int i = 0; i < 5; i++) {
            String string = "String " + i;
            try {
                queue.put(string); // Add string to the queue (blocks if the queue is full)
                Thread.sleep(1000); // Simulate some delay between producing strings
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}

class Consumer implements Runnable {
    private BlockingQueue<String> queue;

    public Consumer(BlockingQueue<String> queue) {
        this.queue = queue;
    }

    @Override
    public void run() {
        // Consume strings and print their lengths
        while (true) {
            try {
                String string = queue.take(); // Take a string from the queue (blocks if the queue is empty)
                System.out.println("Length of '" + string + "': " + string.length());
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}

public class Main {
    public static void main(String[] args) {
        BlockingQueue<String> queue = new LinkedBlockingQueue<>();

        Producer producer = new Producer(queue);
        Consumer consumer = new Consumer(queue);

        Thread producerThread = new Thread(producer);
        Thread consumerThread = new Thread(consumer);

        producerThread.start();
        consumerThread.start();
    }
}
