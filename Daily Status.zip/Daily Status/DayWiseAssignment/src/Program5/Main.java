package Program5;

import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

class CustomerRequest {
    private String customerName;
    private int customerId;
    private String requestText;
    private Date requestDateTime;

    public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getRequestText() {
		return requestText;
	}

	public void setRequestText(String requestText) {
		this.requestText = requestText;
	}

	public Date getRequestDateTime() {
		return requestDateTime;
	}

	public void setRequestDateTime(Date requestDateTime) {
		this.requestDateTime = requestDateTime;
	}

	public CustomerRequest(String customerName, int customerId, String requestText, Date requestDateTime) {
        this.customerName = customerName;
        this.customerId = customerId;
        this.requestText = requestText;
        this.requestDateTime = requestDateTime;
    }

    // Getters and other methods
}

public class Main {
    public static void main(String[] args) {
        // Using LinkedHashSet to maintain insertion order and ensure uniqueness
        Set<CustomerRequest> customerRequestsSet = new LinkedHashSet<>();

        // Adding CustomerRequest objects in the desired order
        customerRequestsSet.add(new CustomerRequest("John Doe", 1, "Request 1", new Date()));
        customerRequestsSet.add(new CustomerRequest("Alice Smith", 2, "Request 2", new Date()));
        customerRequestsSet.add(new CustomerRequest("Bob Johnson", 3, "Request 3", new Date()));

        // Converting LinkedHashSet to ArrayList for random access
        List<CustomerRequest> customerRequestsList = new ArrayList<>(customerRequestsSet);

        // Random access to objects
        CustomerRequest randomRequest = customerRequestsList.get(1);
        System.out.println("Random Customer Request:");
        System.out.println("Customer Name: " + randomRequest.getCustomerName());
        System.out.println("Customer ID: " + randomRequest.getCustomerId());
        System.out.println("Request Text: " + randomRequest.getRequestText());
        System.out.println("Request Date/Time: " + randomRequest.getRequestDateTime());
     // Random access to objects
        CustomerRequest randomRequest1 = customerRequestsList.get(0);
        System.out.println("Random Customer Request:");
        System.out.println("Customer Name: " + randomRequest1.getCustomerName());
        System.out.println("Customer ID: " + randomRequest1.getCustomerId());
        System.out.println("Request Text: " + randomRequest1.getRequestText());
        System.out.println("Request Date/Time: " + randomRequest1.getRequestDateTime());
   
     // Random access to objects
        CustomerRequest randomRequest2 = customerRequestsList.get(2);
        System.out.println("Random Customer Request:");
        System.out.println("Customer Name: " + randomRequest2.getCustomerName());
        System.out.println("Customer ID: " + randomRequest2.getCustomerId());
        System.out.println("Request Text: " + randomRequest2.getRequestText());
        System.out.println("Request Date/Time: " + randomRequest2.getRequestDateTime());
   
    }
}
