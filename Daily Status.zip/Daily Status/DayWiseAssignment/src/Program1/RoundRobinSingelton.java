package Program1;
import java.util.ArrayList;
import java.util.List;

public class RoundRobinSingelton {
    private static RoundRobinSingelton instance;
    private static List<String> objects;
    private static int currentIndex;

    public static List<String> getObjects() {
		return objects;
	}

	public static int getCurrentIndex() {
		return currentIndex;
	}

	private RoundRobinSingelton() {
        objects = new ArrayList();
        objects.add("Object 1");
        objects.add("Object 2");
        objects.add("Object 3");
        currentIndex = 0;
    }

    public static synchronized RoundRobinSingelton getInstance() {
        if (instance == null) {
            instance = new RoundRobinSingelton();
        }
        return instance;
    }

    public synchronized String getNextObject() {
        String object = objects.get(currentIndex);
        currentIndex = (currentIndex + 1) % objects.size();
        System.out.println("Current Index" +currentIndex);
        
        
        return object;
    }
    public static void main(String[] args) {
    	RoundRobinSingelton nc = RoundRobinSingelton.getInstance();
    	nc.getObjects().forEach(System.out::println);
    	nc.getNextObject();
    	RoundRobinSingelton nc1 = RoundRobinSingelton.getInstance();
    	nc1.getNextObject();
    	RoundRobinSingelton nc2 = RoundRobinSingelton.getInstance();
    	nc2.getNextObject();
    }
}
