package Program8;

import java.util.LinkedList;
import java.util.Queue;

class Producer implements Runnable {
    private Queue<String> queue;
    
    public Producer(Queue<String> queue) {
        this.queue = queue;
    }
    
    @Override
    public void run() {
        // Produce strings and add them to the queue
        for (int i = 0; i < 5; i++) {
            String string = "String " + i;
            synchronized (queue) {
                queue.add(string);
                queue.notify(); // Notify the consumer that a new string is available
            }
            try {
                Thread.sleep(1000); // Simulate some delay between producing strings
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}

class Consumer implements Runnable {
    private Queue<String> queue;
    
    public Consumer(Queue<String> queue) {
        this.queue = queue;
    }
    
    @Override
    public void run() {
        // Consume strings and print their lengths
        while (true) {
            synchronized (queue) {
                while (queue.isEmpty()) {
                    try {
                        queue.wait(); // Wait until a new string is available in the queue
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                String string = queue.poll();
                System.out.println("Length of '" + string + "': " + string.length());
            }
        }
    }
}

public class Main {
    public static void main(String[] args) {
        Queue<String> queue = new LinkedList<>();
        
        Producer producer = new Producer(queue);
        Consumer consumer = new Consumer(queue);
        
        Thread producerThread = new Thread(producer);
        Thread consumerThread = new Thread(consumer);
        
        producerThread.start();
        consumerThread.start();
    }
}
