package Program3;
public enum CarType {
    SMALL, SEDAN, LUXURY
}