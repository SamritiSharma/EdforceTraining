package Program6;


import java.util.Iterator;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

class CircularLinkedList<T> implements Iterable<T> {
    private Node<T> head;
    private int size;

    private static class Node<T> {
        private T data;
        private Node<T> next;

        public Node(T data) {
            this.data = data;
            this.next = null;
        }
    }

    public void add(T data) {
        Node<T> newNode = new Node<>(data);

        if (head == null) {
            head = newNode;
            newNode.next = head;
        } else {
            Node<T> current = head;
            while (current.next != head) {
                current = current.next;
            }
            current.next = newNode;
            newNode.next = head;
        }

        size++;
    }

    @Override
    public Iterator<T> iterator() {
        return new CircularLinkedListIterator();
    }

    public Stream<T> stream() {
        Iterable<T> iterable = () -> iterator();
        return StreamSupport.stream(iterable.spliterator(), false);
    }

    private class CircularLinkedListIterator implements Iterator<T> {
        private Node<T> current;
        private int count;

        public CircularLinkedListIterator() {
            current = head;
            count = 0;
        }

        @Override
        public boolean hasNext() {
            return count < size;
        }

        @Override
        public T next() {
            T data = current.data;
            current = current.next;
            count++;
            return data;
        }
    }
}

public class Main {
    public static void main(String[] args) {
        CircularLinkedList<String> circularLinkedList = new CircularLinkedList<>();
        circularLinkedList.add("Object 1");
        circularLinkedList.add("Object 2");
        circularLinkedList.add("Object 3");

        // Iterate and list objects of the Circular Linked List using streaming and method reference
        circularLinkedList.stream().forEach(System.out::println);
    }
}
