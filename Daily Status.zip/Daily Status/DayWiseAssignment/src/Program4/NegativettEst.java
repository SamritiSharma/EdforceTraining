package Program4;


import org.junit.Assert;
import org.junit.Test;
import org.mockito.Mockito;

import java.util.PriorityQueue;

public class NegativettEst {

    @Test(expected = NullPointerException.class)
    public void testNullAuthorInPost() {
        // Create a mocked post with a null author
        Post post = Mockito.mock(Post.class);
        Mockito.when(post.getAuthor()).thenReturn(null);

        // Create the priority queue and add the mocked post
        PriorityQueue<Post> postQueue = new PriorityQueue<>((p1, p2) -> Integer.compare(p1.getAuthor().getRating(), p2.getAuthor().getRating()));
        postQueue.add(post);

        // Attempting to access the null author should throw a NullPointerException
        postQueue.poll();
    }
}
