package Program4;

import org.junit.Assert;
import org.junit.Test;
import org.mockito.Mockito;

import java.util.PriorityQueue;

public class PostSortingTest {

    @Test
    public void testPostOrderingByAuthorRating() {
        // Create mocked posts
        Post post1 = Mockito.mock(Post.class);
        Post post2 = Mockito.mock(Post.class);
        Post post3 = Mockito.mock(Post.class);

        // Set up mocked authors with different ratings
        Author author1 = Mockito.mock(Author.class);
        Author author2 = Mockito.mock(Author.class);
        Author author3 = Mockito.mock(Author.class);

        Mockito.when(post1.getAuthor()).thenReturn(author1);
        Mockito.when(post2.getAuthor()).thenReturn(author2);
        Mockito.when(post3.getAuthor()).thenReturn(author3);

        Mockito.when(author1.getRating()).thenReturn(5);
        Mockito.when(author2.getRating()).thenReturn(3);
        Mockito.when(author3.getRating()).thenReturn(4);

        // Create the priority queue and add the mocked posts
        PriorityQueue<Post> postQueue = new PriorityQueue<>((p1, p2) -> Integer.compare(p1.getAuthor().getRating(), p2.getAuthor().getRating()));
        postQueue.add(post1);
        postQueue.add(post2);
        postQueue.add(post3);

        // Verify the order of posts by author rating
        Assert.assertEquals(post2, postQueue.poll()); // post2 should have the lowest rating
        Assert.assertEquals(post3, postQueue.poll()); // post3 should have the second-lowest rating
        Assert.assertEquals(post1, postQueue.poll()); // post1 should have the highest rating
    }
}
