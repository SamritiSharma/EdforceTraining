package Program4;


import java.util.Comparator;
import java.util.PriorityQueue;

class Post {
    private String postTitle;
    private String description;
    private String tags;
    private Author author;
    private String publishedDateTime;

    public Post(String postTitle, String description, String tags, Author author, String publishedDateTime) {
        this.postTitle = postTitle;
        this.description = description;
        this.tags = tags;
        this.author = author;
        this.publishedDateTime = publishedDateTime;
    }

    public Author getAuthor() {
        return author;
    }

    public String getPostTitle() {
        return postTitle;
    }

    public void displayDetails() {
        System.out.println("Post Title: " + postTitle);
        System.out.println("Description: " + description);
        System.out.println("Tags: " + tags);
        System.out.println("Author: " + author);
        System.out.println("Published Date/Time: " + publishedDateTime);
        System.out.println();
    }
}

public class MainProg {
    public static void main(String[] args) {
        // Comparator using lambda expression to compare authors' ratings
        Comparator<Post> authorRatingComparator = (p1, p2) -> {
            // Assuming the rating is an integer field in the Post class
            int rating1 = p1.getAuthor().getRating();
            int rating2 = p2.getAuthor().getRating();
            return Integer.compare(rating1, rating2);
        };

        // Instantiate PriorityQueue with the lambda expression comparator
        PriorityQueue<Post> postPriorityQueue = new PriorityQueue<>(authorRatingComparator);

        // Add posts to the PriorityQueue
        postPriorityQueue.offer(new Post("Title 1", "Description 1", "Tag1, Tag2", new Author(5), "2023-01-01 10:00:00"));
        postPriorityQueue.offer(new Post("Title 2", "Description 2", "Tag3, Tag4",  new Author(2), "2023-02-01 12:00:00"));
        postPriorityQueue.offer(new Post("Title 3", "Description 3", "Tag5, Tag6",  new Author(8), "2023-03-01 14:00:00"));

        // Iterate over the PriorityQueue and display post details
        while (!postPriorityQueue.isEmpty()) {
            Post post = postPriorityQueue.poll();
            post.displayDetails();
        }
    }
}
