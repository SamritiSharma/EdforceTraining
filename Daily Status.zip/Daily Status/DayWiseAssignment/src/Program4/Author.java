package Program4;

public class Author {
private int rating;

public Author(int rating) {
	super();
	this.rating = rating;
}

public int getRating() {
	return rating;
}

public void setRating(int rating) {
	this.rating = rating;
}

}
