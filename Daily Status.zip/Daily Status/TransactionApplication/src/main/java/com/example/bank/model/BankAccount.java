package com.example.bank.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import org.springframework.stereotype.Component;


@Entity
@Table(name="Bank_Account2")
public class BankAccount {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	int id;
	@NotNull
	@Column
	String name;
	@NotNull
	@Column
	String panCardDetails;
	@Column
	String address;
	@Column
@NotEmpty	String email;
	@Column
	@NotEmpty
	String panNo;
	
	@Column 
	Integer balance;
	public Integer getBalance() {
		return balance;
	}

	public void setBalance(Integer balance) {
		this.balance = balance;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getPanCardDetails() {
		return panCardDetails;
	}

	public void setPanCardDetails(String panCardDetails) {
		this.panCardDetails = panCardDetails;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPanNo() {
		return panNo;
	}

	public void setPanNo(String panNo) {
		this.panNo = panNo;
	}

	public BankAccount(){
		
	}

	public BankAccount(int bid, String name, String address) {
		this.id = bid;
		this.name = name;
		this.address = address;
	}

	public int getBid() {
		return id;
	}

	public void setBid(int bid) {
		this.id = bid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "BankAccount [bid=" + id + ", name=" + name + ", address=" + address + "]";
	}
}

