package com.example.bank.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.bank.model.BankAccount;
import com.example.bank.repo.BankRepository;

@Service
public class BankService {
	@Autowired
	BankRepository bRepository;
	
	public BankAccount createAccount(BankAccount bAccount){
		return bRepository.save(bAccount);
	}
	
	public Optional<BankAccount> fetchAccount(int bid){
		return bRepository.findById((long) bid);
	}

	public void deleteAccount(int id) {
	 bRepository.deleteAccount(id);		
	}

	public void updateAccount(int bid,String name) {
		 bRepository.updateAccount(bid,name);
		//return new BankAccount();
	}
	
}
