package dummy;

public class TestStack {
 static int counter=0;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {

	        System.out.println("Hello"+(counter++));
		main(new String[] {"a","b","c"});

		
System.out.println("test"+counter);
		}
		
		catch(Exception e)
		{
			
		}
	}

}
