package dummy;

class MyOwnClass{
	
	int[] arr=new int[1000000];
}


public class OutOfMemory {

	public static void main(String[] args) {
		int i=0;
		try {
		MyOwnClass cla[]=new MyOwnClass[100000];
		for (;i<cla.length;i++)
		{
			cla[i]=new MyOwnClass();
		}
		} catch(OutOfMemoryError e)
		{
			System.out.println("Iteration"+i);
		}
	}
}
