package com.example999.demo999.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity
@Table(name="Bank_Account")
public class BankAccount {
	@Id
	int id;
	@Column
	String name;
	@Column
	String address;
	
	public BankAccount(){
		
	}

	public BankAccount(int bid, String name, String address) {
		this.id = bid;
		this.name = name;
		this.address = address;
	}

	public int getBid() {
		return id;
	}

	public void setBid(int bid) {
		this.id = bid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "BankAccount [bid=" + id + ", name=" + name + ", address=" + address + "]";
	}
}

