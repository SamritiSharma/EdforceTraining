package com.example999.demo999;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demo999ApplicationTests {

	@Test
	void contextLoads() {
	}

}
