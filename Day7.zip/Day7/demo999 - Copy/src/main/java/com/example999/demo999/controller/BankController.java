package com.example999.demo999.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example999.demo999.model.BankAccount;
import com.example999.demo999.service.BankService;


@RestController //@Component
public class BankController {

	@Autowired
	BankService bService;
	
	@GetMapping("/")
	String met(){
		return "Hello World!!!";
	}

	//converting JSON to Java object - DeSerilization
	@PostMapping("/create")
	int createAccount(@RequestBody BankAccount bAccount){
		System.out.println("Received Bank Account:"+bAccount);
		
		return bService.createAccount(bAccount).getBid();
	}
	
	//retrieve a specific BankAccount details
	// /id/10/20
	// /id?bid=10&abal=20
	@GetMapping("/id")
	BankAccount retrieve(@RequestParam("bid") int bid){
		//retrieve bank account from db
		Optional<BankAccount> bAccount = bService.fetchAccount(bid);
		return bAccount.get();
	}
	
	
	//delete a Bank account
	@DeleteMapping("/id")
	ResponseEntity<Object> delete(@RequestParam("bid") int bid){
		//retrieve bank account from db
		 bService.deleteAccount(bid);
		  return new ResponseEntity<>("Deleted", HttpStatus.OK);
		
	}
	
	//update Bank Account
	@PutMapping("/id")
	ResponseEntity<Object> update(@RequestParam("bid") int bid,@RequestParam("name") String name){
		//retrieve bank account from db
		Optional<BankAccount> bAccount = bService.updateAccount(bid,name);
		  return new ResponseEntity<>("Updated", HttpStatus.OK);
	//	return bAccount.get();
	}
	
}
