package com.example.demo1;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
@RestController
public class TestController {

	
	
	@GetMapping("/app/Sam")

	public String getReqParameter(@RequestParam("name") String name,@RequestParam("id") Integer id) {
return "Name : "+name+" and Id :"+id;
}
}
