
import java.util.Arrays;
import java.util.List;

// Person class having name and age private fields
class Person
{
	private String name;
	private Integer age;

	public Person(String name, Integer age) {
		this.name = name;
		this.age = age;
	}

	public Integer getAge() {
		return age;
	}

	// other getters and setters

	@Override
	public String toString() {
		return "[" + name + ", " + String.valueOf(age) + "]";
	}

	public static Person max(Person x, Person y) {
		return x.getAge() > y.getAge() ? x : y;
	}
}

// Program to find maximum value of a field among custom objects
// using Stream.reduce() method
public class ReduceStreamobject
{
	public static void main(String[] args)
	{
		Person p1 = new Person("George", 15);
		Person p2 = new Person("Tom", 10);
		Person p3 = new Person("Mike", 12);

		List<Person> users = Arrays.asList(p1, p2, p3);

		// get person with maximum age
		Person user = users.stream()
						.reduce(Person::max)
						.get();

		System.out.println("Person with Maximum age is " + user);
	}
}